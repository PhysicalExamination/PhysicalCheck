dpcfg.errAlertMsg = "Invalid date or the date out of range,redo or not?";
dpcfg.aWeekStr = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
dpcfg.aMonStr = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
dpcfg.clearStr = "Clear";
dpcfg.todayStr = "Today";
dpcfg.okStr = "OK";
dpcfg.timeStr = "Time";